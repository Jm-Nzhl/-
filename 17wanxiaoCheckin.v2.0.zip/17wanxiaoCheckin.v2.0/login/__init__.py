# 文件名： __init__
# 创建日期：2020年09月13日09点44分
# 作者：Zhongbr
# 邮箱：zhongbr@icloud.com
"""
修改：ReaJason
修改日期：2021年2月1日
邮箱：reajason@163.com
博客：https://reajason.top
ChangeLog:
1、优化原作者写的账密登录方式和接口替换（server -> app）
2、增加短信登录方式
"""
from login.campus import CampusLogin
